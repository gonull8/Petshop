﻿

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using petshopDB;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Diagnostics;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using System.Globalization;


namespace PETSHOP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        //Veritabanı bağlantısı
        SqlConnection cnn = new SqlConnection("Data Source=DESKTOP-5KNTI5V\\SQLEXPRESS;Initial " +
                            "Catalog=Proje;Integrated Security=True;");

        private void button1_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = textBox2.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username and Password fields cannot be left blank.", "!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;

            }

            try
            {
                cnn.Open();
                string query = "SELECT COUNT(1) FROM login where Username=@username and Password=@password";
                SqlCommand komut = new SqlCommand(query, cnn);
                komut.Parameters.AddWithValue("@username", username);
                komut.Parameters.AddWithValue("@password", password);

                int count = Convert.ToInt32(komut.ExecuteScalar());

                if (count == 1)
                {
                    // Kullanıcı varsa appointments sayfasına yönlendirme
                    Form appointmentsForm = new Appointments();
                    appointmentsForm.Show();
                    this.Hide(); // Login formunu gizler
                }
                else
                {
                    MessageBox.Show("Username or password is incorrect.");
                    // , "", MessageBoxButtons.OK, MessageBoxIcon.Error
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                cnn.Close();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            tabControl1.SelectedTab=tabPage2;
            textBox5.Text=txtUsername.Text;
        }

        //    private void button2_Click(object sender, EventArgs e)
        //    {
        //        if(textBox5.Text=="" || textBox6.Text=="")
        //        {
        //            MessageBox.Show("Please don't leave empty space...");
        //        }
        //        else
        //        {

        //        }
        //        string username = textBox5.Text;
        //        string password = textBox6.Text; 

        //        cnn.Open();
        //        SqlCommand sorgu = new SqlCommand("select * from login where username='"+username+"' ", cnn);
        //        SqlDataReader oku = sorgu.ExecuteReader();

        //        if(oku.Read())
        //        {
        //            //users update password='"+password+"' where username = '"+username+"'",cnn
        //            oku.Close();
        //            SqlCommand update = new SqlCommand("UPDATE login SET Password = @password WHERE Username = @username", cnn);
        //            update.ExecuteNonQuery();
        //            MessageBox.Show("Your password has been updated");
        //        }
        //        else
        //        {
        //            MessageBox.Show("username or password is incorrect!");
        //        }
        //        cnn.Close();
        //    }
        //}

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click_1(object sender, EventArgs e)
        {
            Genel.isLogin=true;
            Butonlar.btnGizle=true;
            Butonlar.btnExit=false;
            this.Close();


            if (Butonlar.btnGizle)
            {
                this.Close();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox5.Text) || string.IsNullOrEmpty(textBox6.Text))
            {
                MessageBox.Show("Please don't leave empty space...");
                return;
            }

            string username = textBox5.Text;
            string password = textBox6.Text;

            try
            {
                cnn.Open();

                SqlCommand sorgu = new SqlCommand("SELECT * FROM login WHERE Username = @username", cnn);
                sorgu.Parameters.AddWithValue("@username", username);
                SqlDataReader oku = sorgu.ExecuteReader();

                if (oku.Read())
                {
                    oku.Close(); // Veritabanı okuyucusunu kapatın

                    SqlCommand update = new SqlCommand("UPDATE login SET Password = @password WHERE Username = @username", cnn);
                    update.Parameters.AddWithValue("@password", password);
                    update.Parameters.AddWithValue("@username", username);
                    update.ExecuteNonQuery();

                    MessageBox.Show("Your password has been updated");
                }
                else
                {
                    MessageBox.Show("Username or password is incorrect!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                cnn.Close();
            }
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = textBox2.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username and Password fields cannot be left blank.", "!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                cnn.Open();
                string query = "SELECT COUNT(1) FROM login WHERE Username=@username AND Password=@password";
                SqlCommand komut = new SqlCommand(query, cnn);
                komut.Parameters.AddWithValue("@username", username);
                komut.Parameters.AddWithValue("@password", password);

                int count = Convert.ToInt32(komut.ExecuteScalar());

                if (count == 1)
                {
                    Genel.isLogin=true;
                    Butonlar.btnGizle=true;


                    this.Close();

                }
                else
                {
                    MessageBox.Show("Username or password is incorrect.", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                cnn.Close();
            }
        }
    }
}