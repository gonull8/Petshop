﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PETSHOP
{
    public class Genel
    {
        static public bool isLogin = false;

    }
    public class Butonlar
    {
        static public bool btnGizle = false;
        static public bool btnExit = false;
    }
  
}
