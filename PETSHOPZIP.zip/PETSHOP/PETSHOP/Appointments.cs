﻿using PETSHOP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;



namespace petshopDB
{
    public partial class Appointments : Form
    {



        public Appointments()
        {
            InitializeComponent();


        }
        public void EnableRandevuAlMenu()
        {
            mnMakeanAppointments.Enabled = true;
        }
        public void EnabledButonlarıGizle()
        {
            btnLogin.Enabled = true;
            button4.Enabled=true;
        }
        private void hakkımızdaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            randevuAl randevuForm = new randevuAl();
            randevuForm.ShowDialog();
        }
        //private void SearchControls(Control control, string searchTerm)
        //{
        //    foreach (Control kontrol in control.Controls)
        //    {
        //       // Label, TextBox, ListBox vb. kontrollerde arama yap
        //        if (kontrol is Label || kontrol is Appointments || kontrol is ListBox)
        //        {
        //            if (kontrol.Text.ToLower().Contains(searchTerm))
        //            {
        //                // Aranan terim bulunduğunda ilgili kontrolü vurgulayabiliriz
        //                kontrol.BackColor = Color.Yellow;
        //            }
        //            else
        //            {
        //                // Aranan terim yoksa varsayılan rengi kullan
        //                kontrol.BackColor = SystemColors.Control;
        //                MessageBox.Show("No result found");
        //            }
        //        }

        //        // Eğer kontrolün içinde başka kontroller varsa onları da tara
        //        if (kontrol.HasChildren)
        //        {
        //            SearchControls(kontrol, searchTerm);
        //        }
        //    }
        //}

        private void button2_Click(object sender, EventArgs e)
        {
            // Aranacak kelimeyi gir
            string searchText = textBox1.Text;

            // Eğer textbox boş ise hata mesajı ver
            if (string.IsNullOrWhiteSpace(searchText))
            {
                MessageBox.Show("Please enter the word you want to search.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            bool found = false;

            // Tüm form üzerindeki kontrol elemanlarını dolaş
            foreach (Control kontrol in this.Controls)
            {
                if (kontrol is System.Windows.Forms.Button)
                {
                    System.Windows.Forms.Button btn = (System.Windows.Forms.Button)kontrol;
                    if (btn.Text.Contains(searchText))
                    {
                        btn.BackColor=Color.Yellow;
                    }
                }

                if (kontrol is System.Windows.Forms.Label)
                {
                    System.Windows.Forms.Label lbl = (System.Windows.Forms.Label)kontrol;
                    if (lbl.Text.Contains(searchText))
                    {
                        lbl.BackColor=Color.Yellow;
                    }
                }
                // MenuStripte kelimeyi kontrol et
                if (kontrol is MenuStrip)
                {
                    MenuStrip menuStrip = kontrol as MenuStrip;

                    // Menü öğelerini dolaş
                    foreach (ToolStripMenuItem item in menuStrip.Items)
                    {
                        // Eğer Menü öğesi aranacak kelimeyi içeriyorsa
                        if (item.Text.Contains(searchText))
                        {
                            // Arka plan rengini sarı yap
                            item.BackColor = Color.Yellow;
                            found = true;
                        }
                        else
                        {
                            // Eşleşme yoksa normal arka plan rengine geri dön
                            item.BackColor = SystemColors.Control;
                        }
                    }
                }
            }

            // aranan kelime yoksa hata mesajı verir
            if (!found)
            {
                MessageBox.Show("The searched word was not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void hakkımızdaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Hakkimizda hakkimizdaForm = new Hakkimizda();
            hakkimizdaForm.ShowDialog();
        }
        private void kediİlanlarıToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            kediİlanlari KediForm = new kediİlanlari();
            KediForm.ShowDialog();
        }
        private void köpekİlanlarıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            köpekİlanları köpekForm = new köpekİlanları();
            köpekForm.ShowDialog();
        }

        private void hakkımızdaToolStripMenuItem1_Click_2(object sender, EventArgs e)
        {
            Hakkimizda hakkimizdaForm = new Hakkimizda();
            hakkimizdaForm.ShowDialog();
        }
        private void button3_Click_1(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.ShowDialog();
            this.Hide();

        }
        //private void button4_Click(object sender, EventArgs e)
        //{
        //    Register rgstr = new Register();
        //    rgstr.ShowDialog();
        //    this.Hide();
        //}

        private void Appointments_Load(object sender, EventArgs e)
        {
            mnMakeanAppointments.Enabled=false;
            btnExit.Enabled=false;

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Genel.isLogin=false;
            btnLogin.Enabled = false;
            button4.Enabled=false;
            btnExit.Enabled=false;


            Form1 frm = new Form1();
            frm.ShowDialog();

            if (Genel.isLogin)
            {
                mnMakeanAppointments.Enabled=true;
                btnExit.Enabled=true;
                //btnLogin.Enabled=true;

            }
            else
            {
                mnMakeanAppointments.Enabled=false;
                btnExit.Enabled=false;
                btnLogin.Enabled=true;
            }

        }
        private void btnRegister(object sender, EventArgs e)
        {
            Register rgstr = new Register();
            rgstr.ShowDialog();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //btnExit.Enabled=false;
            //btnLogin.Enabled=true;
            lambaKapat();
        }
        private void lambaAc()
        {
            mnMakeanAppointments.Enabled=true;
            btnExit.Enabled=true;
            btnLogin.Enabled=false;
            button4.Enabled = false;
        }
        private void lambaKapat()
        {
            mnMakeanAppointments.Enabled=false;
            btnExit.Enabled=false;
            btnLogin.Enabled=true;
            button4.Enabled = true;
        }
    }
}

   

