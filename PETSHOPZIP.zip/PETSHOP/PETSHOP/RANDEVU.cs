﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PETSHOP
{
    internal class RANDEVU
    {
        public int Musteri_id { get; set; }
        public int Hayvan_id { get; set; }
        public DateTime date { get; set; }
        public string konu { get; set; }
        public string onay { get; set; }

    }

}
