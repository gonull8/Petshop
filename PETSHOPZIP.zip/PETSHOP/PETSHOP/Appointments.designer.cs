﻿namespace petshopDB
{
    partial class Appointments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.evcilDostlarımızToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kedilerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.köpeklerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kuşlarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.balıklarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sürüngenlerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.diğerMemelilerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.böceklerDiğerOmurgasızlarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bölümlerimizToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.genelCerrahiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ortopediToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dahiliyeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gözHastalıklarıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dişHekimliğiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.onkolojiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dermatolojiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.beslenmeUzmanlığıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.acilVeterinerlikToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.endokrinolojiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kardiyolojiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.radyolojiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.patolojiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fizyoterapiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kliniklerimizToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.animalHospitalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guaHospitalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shineHospitalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roseHospitalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yuvaArayanlarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kediİlanlarıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.köpekİlanlarıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ürünlerimizAksesuarlarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mamalarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kediMamalarıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.köpekMamalarıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kuşYemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.balıkYemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kaplarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnMakeanAppointments = new System.Windows.Forms.ToolStripMenuItem();
            this.hakkımızdaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button1.Font = new System.Drawing.Font("Palatino Linotype", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.Color.DarkRed;
            this.button1.Location = new System.Drawing.Point(-9, -4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(1022, 61);
            this.button1.TabIndex = 1;
            this.button1.Text = " ";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.evcilDostlarımızToolStripMenuItem,
            this.bölümlerimizToolStripMenuItem,
            this.kliniklerimizToolStripMenuItem,
            this.yuvaArayanlarToolStripMenuItem,
            this.ürünlerimizAksesuarlarToolStripMenuItem,
            this.mnMakeanAppointments,
            this.hakkımızdaToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(49, 60);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(883, 28);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // evcilDostlarımızToolStripMenuItem
            // 
            this.evcilDostlarımızToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kedilerToolStripMenuItem,
            this.köpeklerToolStripMenuItem,
            this.kuşlarToolStripMenuItem,
            this.balıklarToolStripMenuItem,
            this.sürüngenlerToolStripMenuItem,
            this.diğerMemelilerToolStripMenuItem,
            this.böceklerDiğerOmurgasızlarToolStripMenuItem});
            this.evcilDostlarımızToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.evcilDostlarımızToolStripMenuItem.Name = "evcilDostlarımızToolStripMenuItem";
            this.evcilDostlarımızToolStripMenuItem.Size = new System.Drawing.Size(98, 24);
            this.evcilDostlarımızToolStripMenuItem.Text = "Pet Friends";
            // 
            // kedilerToolStripMenuItem
            // 
            this.kedilerToolStripMenuItem.Name = "kedilerToolStripMenuItem";
            this.kedilerToolStripMenuItem.Size = new System.Drawing.Size(290, 26);
            this.kedilerToolStripMenuItem.Text = "Kediler";
            // 
            // köpeklerToolStripMenuItem
            // 
            this.köpeklerToolStripMenuItem.Name = "köpeklerToolStripMenuItem";
            this.köpeklerToolStripMenuItem.Size = new System.Drawing.Size(290, 26);
            this.köpeklerToolStripMenuItem.Text = "Köpekler";
            // 
            // kuşlarToolStripMenuItem
            // 
            this.kuşlarToolStripMenuItem.Name = "kuşlarToolStripMenuItem";
            this.kuşlarToolStripMenuItem.Size = new System.Drawing.Size(290, 26);
            this.kuşlarToolStripMenuItem.Text = "Kuşlar";
            // 
            // balıklarToolStripMenuItem
            // 
            this.balıklarToolStripMenuItem.Name = "balıklarToolStripMenuItem";
            this.balıklarToolStripMenuItem.Size = new System.Drawing.Size(290, 26);
            this.balıklarToolStripMenuItem.Text = "Balıklar";
            // 
            // sürüngenlerToolStripMenuItem
            // 
            this.sürüngenlerToolStripMenuItem.Name = "sürüngenlerToolStripMenuItem";
            this.sürüngenlerToolStripMenuItem.Size = new System.Drawing.Size(290, 26);
            this.sürüngenlerToolStripMenuItem.Text = "Sürüngenler";
            // 
            // diğerMemelilerToolStripMenuItem
            // 
            this.diğerMemelilerToolStripMenuItem.Name = "diğerMemelilerToolStripMenuItem";
            this.diğerMemelilerToolStripMenuItem.Size = new System.Drawing.Size(290, 26);
            this.diğerMemelilerToolStripMenuItem.Text = "Diğer Memeliler";
            // 
            // böceklerDiğerOmurgasızlarToolStripMenuItem
            // 
            this.böceklerDiğerOmurgasızlarToolStripMenuItem.Name = "böceklerDiğerOmurgasızlarToolStripMenuItem";
            this.böceklerDiğerOmurgasızlarToolStripMenuItem.Size = new System.Drawing.Size(290, 26);
            this.böceklerDiğerOmurgasızlarToolStripMenuItem.Text = "Böcekler & Diğer Omurgasızlar";
            // 
            // bölümlerimizToolStripMenuItem
            // 
            this.bölümlerimizToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.genelCerrahiToolStripMenuItem,
            this.ortopediToolStripMenuItem,
            this.dahiliyeToolStripMenuItem,
            this.gözHastalıklarıToolStripMenuItem,
            this.dişHekimliğiToolStripMenuItem,
            this.onkolojiToolStripMenuItem,
            this.dermatolojiToolStripMenuItem,
            this.beslenmeUzmanlığıToolStripMenuItem,
            this.acilVeterinerlikToolStripMenuItem,
            this.endokrinolojiToolStripMenuItem,
            this.kardiyolojiToolStripMenuItem,
            this.radyolojiToolStripMenuItem,
            this.patolojiToolStripMenuItem,
            this.fizyoterapiToolStripMenuItem});
            this.bölümlerimizToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bölümlerimizToolStripMenuItem.Name = "bölümlerimizToolStripMenuItem";
            this.bölümlerimizToolStripMenuItem.Size = new System.Drawing.Size(110, 24);
            this.bölümlerimizToolStripMenuItem.Text = "Departments";
            // 
            // genelCerrahiToolStripMenuItem
            // 
            this.genelCerrahiToolStripMenuItem.Name = "genelCerrahiToolStripMenuItem";
            this.genelCerrahiToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.genelCerrahiToolStripMenuItem.Text = "Genel Cerrahi";
            // 
            // ortopediToolStripMenuItem
            // 
            this.ortopediToolStripMenuItem.Name = "ortopediToolStripMenuItem";
            this.ortopediToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.ortopediToolStripMenuItem.Text = "Ortopedi";
            // 
            // dahiliyeToolStripMenuItem
            // 
            this.dahiliyeToolStripMenuItem.Name = "dahiliyeToolStripMenuItem";
            this.dahiliyeToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.dahiliyeToolStripMenuItem.Text = "Dahiliye";
            // 
            // gözHastalıklarıToolStripMenuItem
            // 
            this.gözHastalıklarıToolStripMenuItem.Name = "gözHastalıklarıToolStripMenuItem";
            this.gözHastalıklarıToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.gözHastalıklarıToolStripMenuItem.Text = "Göz Hastalıkları";
            // 
            // dişHekimliğiToolStripMenuItem
            // 
            this.dişHekimliğiToolStripMenuItem.Name = "dişHekimliğiToolStripMenuItem";
            this.dişHekimliğiToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.dişHekimliğiToolStripMenuItem.Text = "Diş Hekimliği";
            // 
            // onkolojiToolStripMenuItem
            // 
            this.onkolojiToolStripMenuItem.Name = "onkolojiToolStripMenuItem";
            this.onkolojiToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.onkolojiToolStripMenuItem.Text = "Onkoloji";
            // 
            // dermatolojiToolStripMenuItem
            // 
            this.dermatolojiToolStripMenuItem.Name = "dermatolojiToolStripMenuItem";
            this.dermatolojiToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.dermatolojiToolStripMenuItem.Text = "Dermatoloji";
            // 
            // beslenmeUzmanlığıToolStripMenuItem
            // 
            this.beslenmeUzmanlığıToolStripMenuItem.Name = "beslenmeUzmanlığıToolStripMenuItem";
            this.beslenmeUzmanlığıToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.beslenmeUzmanlığıToolStripMenuItem.Text = "Beslenme Uzmanlığı";
            // 
            // acilVeterinerlikToolStripMenuItem
            // 
            this.acilVeterinerlikToolStripMenuItem.Name = "acilVeterinerlikToolStripMenuItem";
            this.acilVeterinerlikToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.acilVeterinerlikToolStripMenuItem.Text = "Acil Veterinerlik";
            // 
            // endokrinolojiToolStripMenuItem
            // 
            this.endokrinolojiToolStripMenuItem.Name = "endokrinolojiToolStripMenuItem";
            this.endokrinolojiToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.endokrinolojiToolStripMenuItem.Text = "Endokrinoloji";
            // 
            // kardiyolojiToolStripMenuItem
            // 
            this.kardiyolojiToolStripMenuItem.Name = "kardiyolojiToolStripMenuItem";
            this.kardiyolojiToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.kardiyolojiToolStripMenuItem.Text = "Kardiyoloji";
            // 
            // radyolojiToolStripMenuItem
            // 
            this.radyolojiToolStripMenuItem.Name = "radyolojiToolStripMenuItem";
            this.radyolojiToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.radyolojiToolStripMenuItem.Text = "Radyoloji";
            // 
            // patolojiToolStripMenuItem
            // 
            this.patolojiToolStripMenuItem.Name = "patolojiToolStripMenuItem";
            this.patolojiToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.patolojiToolStripMenuItem.Text = "Patoloji";
            // 
            // fizyoterapiToolStripMenuItem
            // 
            this.fizyoterapiToolStripMenuItem.Name = "fizyoterapiToolStripMenuItem";
            this.fizyoterapiToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.fizyoterapiToolStripMenuItem.Text = "Fizyoterapi";
            // 
            // kliniklerimizToolStripMenuItem
            // 
            this.kliniklerimizToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.animalHospitalToolStripMenuItem,
            this.guaHospitalToolStripMenuItem,
            this.shineHospitalToolStripMenuItem,
            this.roseHospitalToolStripMenuItem});
            this.kliniklerimizToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kliniklerimizToolStripMenuItem.Name = "kliniklerimizToolStripMenuItem";
            this.kliniklerimizToolStripMenuItem.Size = new System.Drawing.Size(67, 24);
            this.kliniklerimizToolStripMenuItem.Text = "Clinics";
            // 
            // animalHospitalToolStripMenuItem
            // 
            this.animalHospitalToolStripMenuItem.Name = "animalHospitalToolStripMenuItem";
            this.animalHospitalToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.animalHospitalToolStripMenuItem.Text = "Animal Hospital";
            // 
            // guaHospitalToolStripMenuItem
            // 
            this.guaHospitalToolStripMenuItem.Name = "guaHospitalToolStripMenuItem";
            this.guaHospitalToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.guaHospitalToolStripMenuItem.Text = "Gua Hospital";
            // 
            // shineHospitalToolStripMenuItem
            // 
            this.shineHospitalToolStripMenuItem.Name = "shineHospitalToolStripMenuItem";
            this.shineHospitalToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.shineHospitalToolStripMenuItem.Text = "Shine Hospital";
            // 
            // roseHospitalToolStripMenuItem
            // 
            this.roseHospitalToolStripMenuItem.Name = "roseHospitalToolStripMenuItem";
            this.roseHospitalToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.roseHospitalToolStripMenuItem.Text = "Rose Hospital";
            // 
            // yuvaArayanlarToolStripMenuItem
            // 
            this.yuvaArayanlarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kediİlanlarıToolStripMenuItem,
            this.köpekİlanlarıToolStripMenuItem});
            this.yuvaArayanlarToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.yuvaArayanlarToolStripMenuItem.Name = "yuvaArayanlarToolStripMenuItem";
            this.yuvaArayanlarToolStripMenuItem.Size = new System.Drawing.Size(187, 24);
            this.yuvaArayanlarToolStripMenuItem.Text = "Those looking for a home";
            // 
            // kediİlanlarıToolStripMenuItem
            // 
            this.kediİlanlarıToolStripMenuItem.Name = "kediİlanlarıToolStripMenuItem";
            this.kediİlanlarıToolStripMenuItem.Size = new System.Drawing.Size(186, 26);
            this.kediİlanlarıToolStripMenuItem.Text = "Kedi İlanları";
            this.kediİlanlarıToolStripMenuItem.Click += new System.EventHandler(this.kediİlanlarıToolStripMenuItem_Click_1);
            // 
            // köpekİlanlarıToolStripMenuItem
            // 
            this.köpekİlanlarıToolStripMenuItem.Name = "köpekİlanlarıToolStripMenuItem";
            this.köpekİlanlarıToolStripMenuItem.Size = new System.Drawing.Size(186, 26);
            this.köpekİlanlarıToolStripMenuItem.Text = "Köpek İlanları";
            this.köpekİlanlarıToolStripMenuItem.Click += new System.EventHandler(this.köpekİlanlarıToolStripMenuItem_Click);
            // 
            // ürünlerimizAksesuarlarToolStripMenuItem
            // 
            this.ürünlerimizAksesuarlarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mamalarToolStripMenuItem,
            this.kaplarToolStripMenuItem});
            this.ürünlerimizAksesuarlarToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ürünlerimizAksesuarlarToolStripMenuItem.Name = "ürünlerimizAksesuarlarToolStripMenuItem";
            this.ürünlerimizAksesuarlarToolStripMenuItem.Size = new System.Drawing.Size(173, 24);
            this.ürünlerimizAksesuarlarToolStripMenuItem.Text = "Products / Accessories";
            // 
            // mamalarToolStripMenuItem
            // 
            this.mamalarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kediMamalarıToolStripMenuItem,
            this.köpekMamalarıToolStripMenuItem,
            this.kuşYemleriToolStripMenuItem,
            this.balıkYemleriToolStripMenuItem});
            this.mamalarToolStripMenuItem.Name = "mamalarToolStripMenuItem";
            this.mamalarToolStripMenuItem.Size = new System.Drawing.Size(152, 26);
            this.mamalarToolStripMenuItem.Text = "Mamalar";
            // 
            // kediMamalarıToolStripMenuItem
            // 
            this.kediMamalarıToolStripMenuItem.Name = "kediMamalarıToolStripMenuItem";
            this.kediMamalarıToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.kediMamalarıToolStripMenuItem.Text = "Kedi mamaları";
            // 
            // köpekMamalarıToolStripMenuItem
            // 
            this.köpekMamalarıToolStripMenuItem.Name = "köpekMamalarıToolStripMenuItem";
            this.köpekMamalarıToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.köpekMamalarıToolStripMenuItem.Text = "Köpek mamaları";
            // 
            // kuşYemleriToolStripMenuItem
            // 
            this.kuşYemleriToolStripMenuItem.Name = "kuşYemleriToolStripMenuItem";
            this.kuşYemleriToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.kuşYemleriToolStripMenuItem.Text = "Kuş yemleri";
            // 
            // balıkYemleriToolStripMenuItem
            // 
            this.balıkYemleriToolStripMenuItem.Name = "balıkYemleriToolStripMenuItem";
            this.balıkYemleriToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.balıkYemleriToolStripMenuItem.Text = "Balık yemleri";
            // 
            // kaplarToolStripMenuItem
            // 
            this.kaplarToolStripMenuItem.Name = "kaplarToolStripMenuItem";
            this.kaplarToolStripMenuItem.Size = new System.Drawing.Size(152, 26);
            this.kaplarToolStripMenuItem.Text = "Kaplar";
            // 
            // mnMakeanAppointments
            // 
            this.mnMakeanAppointments.Font = new System.Drawing.Font("Palatino Linotype", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mnMakeanAppointments.Name = "mnMakeanAppointments";
            this.mnMakeanAppointments.Size = new System.Drawing.Size(176, 24);
            this.mnMakeanAppointments.Text = "Make an Appointments";
            this.mnMakeanAppointments.Click += new System.EventHandler(this.hakkımızdaToolStripMenuItem_Click);
            // 
            // hakkımızdaToolStripMenuItem1
            // 
            this.hakkımızdaToolStripMenuItem1.Font = new System.Drawing.Font("Palatino Linotype", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.hakkımızdaToolStripMenuItem1.Name = "hakkımızdaToolStripMenuItem1";
            this.hakkımızdaToolStripMenuItem1.Size = new System.Drawing.Size(64, 24);
            this.hakkımızdaToolStripMenuItem1.Text = "About";
            this.hakkımızdaToolStripMenuItem1.Click += new System.EventHandler(this.hakkımızdaToolStripMenuItem1_Click_2);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 22);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(195, 22);
            this.textBox1.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.Font = new System.Drawing.Font("Palatino Linotype", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.Location = new System.Drawing.Point(213, 17);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(81, 32);
            this.button2.TabIndex = 4;
            this.button2.Text = "Search";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnLogin
            // 
            this.btnLogin.Font = new System.Drawing.Font("Palatino Linotype", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnLogin.Location = new System.Drawing.Point(788, 7);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(90, 36);
            this.btnLogin.TabIndex = 7;
            this.btnLogin.Text = "LOG İN ";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(398, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 44);
            this.label1.TabIndex = 8;
            this.label1.Text = "PET22";
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button4.Location = new System.Drawing.Point(884, 6);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(104, 37);
            this.button4.TabIndex = 9;
            this.button4.Text = "Register";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.btnRegister);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::PETSHOP.Properties.Resources.iconSearch;
            this.pictureBox1.Location = new System.Drawing.Point(181, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(26, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Palatino Linotype", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnExit.Location = new System.Drawing.Point(721, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(61, 32);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Appointments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PETSHOP.Properties.Resources.homeBckgrnd;
            this.ClientSize = new System.Drawing.Size(1011, 736);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Appointments";
            this.Text = "Appointments";
            this.Load += new System.EventHandler(this.Appointments_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem evcilDostlarımızToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bölümlerimizToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kliniklerimizToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yuvaArayanlarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ürünlerimizAksesuarlarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnMakeanAppointments;
        private System.Windows.Forms.ToolStripMenuItem hakkımızdaToolStripMenuItem1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem kedilerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem köpeklerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kuşlarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem balıklarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sürüngenlerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem diğerMemelilerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem böceklerDiğerOmurgasızlarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem genelCerrahiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ortopediToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dahiliyeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gözHastalıklarıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dişHekimliğiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem onkolojiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dermatolojiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem beslenmeUzmanlığıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem acilVeterinerlikToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem endokrinolojiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kardiyolojiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem radyolojiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem patolojiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fizyoterapiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem animalHospitalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guaHospitalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shineHospitalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roseHospitalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kediİlanlarıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem köpekİlanlarıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mamalarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kediMamalarıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem köpekMamalarıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kuşYemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem balıkYemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kaplarToolStripMenuItem;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button btnExit;
    }
}