﻿using PETSHOP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace petshopDB
{
    public partial class randevuAl : Form
    {

        string writemessage
        {
            set
            {

                olblMsg.Text= string.Format("{0} - {1} ", DateTime.Now.ToLongTimeString(), value);
                olblMsg.Visible=true;
                Application.DoEvents();
                System.Threading.Thread.Sleep(1500);
            }
        }
        string writeErrmessage
        {
            set
            {

                writemessage = value;
                //olblMsg.Text=value;
                //olblMsg.Visible=true;
                //Application.DoEvents();
                //System.Threading.Thread.Sleep(1500);

                olblMsg.BackColor = Color.Red;

                olblMsg.ForeColor= Color.White;
            }
        }
        // SqlDataAdapter da;
        public randevuAl()
        {
            InitializeComponent();
        }

        //void listele()
        //{
        //    baglanti.Open();
        //    da = new SqlDataAdapter("Select * from [dbo].[Randevular]", baglanti);
        //    DataTable dt= new DataTable();
        //    da.Fill(dt);
        //    dataGridView1.DataSource= dt;



        //    baglanti.Close();
        //}

        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-5KNTI5V\SQLEXPRESS;Initial Catalog=Proje;Integrated Security=True;");



        private void pictureBox3_Click(object sender, EventArgs e)
        {
            //Appointments appointments = new Appointments();
            //appointments.ShowDialog();
            this.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            RANDEVU newRandevu = new RANDEVU();

            if (string.IsNullOrWhiteSpace(txtRandevuName.Text) || string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(comboBox2.Text) || string.IsNullOrWhiteSpace(textBox4.Text))

            {
                MessageBox.Show("Please don't leave empty space", "", MessageBoxButtons.OK, MessageBoxIcon.Error);

                //newRandevu.Musteri_id=101;
                //newRandevu.Hayvan_id=5;
                //newRandevu.date=DateTime.Now;
                //newRandevu.konu="Aşı";
                //newRandevu.onay="f";
                
                insertodata(newRandevu);

            }

            try
            {
                writemessage="hazırlanıyor";



                //baglanti.Open();

                // randevular tablosuna veri ekleme
                //using (SqlCommand komut = new SqlCommand("INSERT INTO [dbo].[Randevular] (Randevu_Konusu ) VALUES (@Randevu_Konusu)", baglanti))
                //{
                //    //komut.Parameters.AddWithValue("@Name", textBox1.Text);
                //    //komut.Parameters.AddWithValue("@Surname", textBox2.Text);
                //   // komut.Parameters.AddWithValue("@Randevu_tarihSaat", dateTimePicker1.Text);
                //    komut.Parameters.AddWithValue("@Randevu_Konusu", textBox4.Text);
                //    komut.ExecuteNonQuery();
                //}

                //MessageBox.Show("successfull!");


                //   listele();

                // string connectionString = "Data Source=server_name;Initial Catalog=database_name;User ID=user;Password=password";
                string query = "Insert Into [dbo].[RandevularG] (Musteri_adi, Musteri_soyadi, Randevu_tarihSaat, HayvanTur, Randevu_konusu) " +
                               "values (@MusteriAd, @MusteriSoyad, @RandevuTarihi, @HayvanTur, @RandevuKonu)";

                using (SqlCommand command = new SqlCommand(query, baglanti))
                {
                    command.Parameters.AddWithValue("@MusteriAd", txtRandevuName.Text);
                    command.Parameters.AddWithValue("MusteriSoyad", textBox2.Text);
                    command.Parameters.AddWithValue("@RandevuTarihi", dateTimePicker1.Value);
                    command.Parameters.AddWithValue("@HayvanTur", comboBox2.Text);
                    //command.Parameters.AddWithValue("@HayvanTipi", comboBox1.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@RandevuKonu", textBox4.Text);
                    

                    // Bağlantıyı aç ve sorguyu çalıştır
                    writemessage="bağlantı açılıyor"; 
                    baglanti.Open();
                    writemessage="komut çalıştırılmaya hazırlanıyor";
                    int sonuc = command.ExecuteNonQuery();
                    writeErrmessage ="Sonuc " + sonuc.ToString();
                    baglanti.Close();
                }

                tabControl1.SelectedTab=tabPage2;

                label14.Text = txtRandevuName.Text;
                label15.Text=textBox2.Text;
                label16.Text=dateTimePicker1.Text;
                label17.Text=comboBox2.Text;
                label18.Text=textBox4.Text;

            }
            catch (Exception Ex)
            {
                //MessageBox.Show("Error: " + Ex.Message);
                //writemessage="Error: " + Ex.Message;,
                writeErrmessage="Error: " + Ex.Message;
            }
            finally
            {
                baglanti.Close();
            }
        }

        private void randevuAl_Load(object sender, EventArgs e)
        {
            comboDoldur();
        }

        private void olblMsg_Click(object sender, EventArgs e)
        {
            olblMsg.Visible=false;
        }
        private void comboDoldur()
        {   // COMBOBOXTAKİ HAYVAN TÜRLERİNİ VERİTABANINDA HAYVANLAR TABLOSUNDAN ÇEKME
            string query = @"select * from HayvanTuru";
            SqlCommand com = new SqlCommand(query, baglanti);
            SqlDataAdapter adapter = new SqlDataAdapter(com);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            comboBox2.DataSource=dataTable;
            comboBox2.DisplayMember="HayvanTuru";
            comboBox2.ValueMember="HayvanTur_ID";
        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void insertodata(RANDEVU rnd)
        {
            try
            {
                baglanti.Open();
                string query = @"INSERT INTO [dbo].[Randevular] (Musteri_ID, Hayvan_ID, Randevu_tarihSaat, Randevu_konusu,Durum)
                    VALUES (@MUSTERİıd,@hayvanID, @TARİH, @KONU, @DURUM)";
                SqlCommand cmm = new SqlCommand(query, baglanti);
                cmm.Parameters.AddWithValue("MUSTERİıd", rnd.Musteri_id);
                cmm.Parameters.AddWithValue("hayvanID", rnd.Hayvan_id);
                cmm.Parameters.AddWithValue("TARİH", rnd.date);
                cmm.Parameters.AddWithValue("KONU", rnd.konu);
                cmm.Parameters.AddWithValue("DURUM", rnd.onay);
                cmm.ExecuteNonQuery();

                MessageBox.Show("ekleme başarılı");


            }
            catch (Exception Ex)
            {

            }
            finally
            {
                baglanti.Close();
            }
        }
    }
}
