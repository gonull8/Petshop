﻿using petshopDB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PETSHOP
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        SqlConnection baglanti = new SqlConnection(@"Data Source=DESKTOP-5KNTI5V\SQLEXPRESS;Initial Catalog=Proje;Integrated Security=True;");

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        private void Register_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click_1(object sender, EventArgs e)
        {
            this.Close();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string password = textBox4.Text;

            if (password.Length < 8)
            {
                MessageBox.Show("Your password must be at least 8 characters long!");
                return;
            }

            try
            {
                baglanti.Open();

                // register tablosuna veri ekleme
                using (SqlCommand komut = new SqlCommand("INSERT INTO register (Name, Surname, Username, Password) VALUES (@Name, @Surname, @Username, @Password)", baglanti))
                {
                    komut.Parameters.AddWithValue("@Name", textBox1.Text);
                    komut.Parameters.AddWithValue("@Surname", textBox2.Text);
                    komut.Parameters.AddWithValue("@Username", textBox3.Text);
                    komut.Parameters.AddWithValue("@Password", textBox4.Text);
                    komut.ExecuteNonQuery(); 

                }

                // login tablosuna veri ekleme
                using (SqlCommand komut2 = new SqlCommand("INSERT INTO Login (Username, Password) VALUES (@Username, @Password)", baglanti))
                {
                    komut2.Parameters.AddWithValue("@Username", textBox3.Text);
                    komut2.Parameters.AddWithValue("@Password", textBox4.Text);
                    komut2.ExecuteNonQuery();
                }

                MessageBox.Show("Your registration has been made successfully!");

            }
            catch (Exception Ex)
            {
                MessageBox.Show("Error: " + Ex.Message);
            }
            finally
            {
                baglanti.Close();
            }

            Form1 rgstr = new Form1();
            rgstr.Show();
            //this.Hide();
            this.Close();

        }
        
    }
}
   